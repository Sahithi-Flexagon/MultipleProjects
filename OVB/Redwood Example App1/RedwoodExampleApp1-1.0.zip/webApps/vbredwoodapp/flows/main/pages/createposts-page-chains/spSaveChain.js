/* Copyright (c) 2023, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class spSaveChain extends ActionChain {

    /**
     * Submit form data
     * @param {Object} context
     */
    async run(context) {
      const { $page }  = context;

      if ('true') {

        const callRestJSONPostPotsResult = await Actions.callRest(context, {
          endpoint: 'JSON/postPots',
          body: $page.variables.postPots,
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'New post added successfully',
        });

        // Reset dirty data
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.dirtyDataFlag',
          ],
        });

        $page.variables.isSaved = true;
      }
    }
  }

  return spSaveChain;
});
